# Revisi BPMN SmartCoop

Paket ini berisi 8 file BPMN XML revisi untuk Camunda Modeler, dengan struktur folder yang mengikuti repository asal.

## Fokus revisi

- Alur dibuat dari sudut pandang proses bisnis koperasi, bukan urutan klik halaman aplikasi.
- Bahasa pada aktivitas dibuat lebih mudah dibaca oleh pengurus, anggota, dan dosen penguji.
- Notasi BPMN dibuat lebih bervariasi dan relevan, termasuk Exclusive Gateway, Inclusive Gateway, Parallel Gateway, Event-Based Gateway, Timer Event, Message Event, User Task, Manual Task, Service Task, Send Task, dan Business Rule Task.
- Tata letak disusun horizontal dengan lane aktor agar garis tidak saling menumpuk saat dibuka di Camunda Modeler.

## File

- refrensi/bpmn/as-is/manajemen-anggota.bpmn
- refrensi/bpmn/as-is/simpanan.bpmn
- refrensi/bpmn/as-is/pengajuan.bpmn
- refrensi/bpmn/as-is/shu.bpmn
- refrensi/bpmn/to_be/manajemen-anggota.bpmn
- refrensi/bpmn/to_be/simpanan.bpmn
- refrensi/bpmn/to_be/pengajuan.bpmn
- refrensi/bpmn/to_be/shu.bpmn
